#ifndef _WIMLIB_WIN32_COMPAT_H
#define _WIMLIB_WIN32_COMPAT_H

#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <windows.h>

// port: provide legacy windows replacements for missing runtime functions
// port: translate legacy win32 errors for replacement runtime calls
static inline void
win32_compat_set_errno(DWORD err)
{
	switch (err) {
	case ERROR_FILE_NOT_FOUND:
	case ERROR_PATH_NOT_FOUND:
	case ERROR_INVALID_NAME:
		errno = ENOENT;
		break;
	case ERROR_ACCESS_DENIED:
	case ERROR_SHARING_VIOLATION:
		errno = EACCES;
		break;
	case ERROR_INVALID_HANDLE:
		errno = EBADF;
		break;
	default:
		errno = EINVAL;
		break;
	}
}

// port: convert file times without newer runtime helpers
static inline __time64_t
win32_compat_filetime_to_time(FILETIME time)
{
	ULARGE_INTEGER value;

	value.LowPart = time.dwLowDateTime;
	value.HighPart = time.dwHighDateTime;
	return (__time64_t)(value.QuadPart / 10000000) - 11644473600LL;
}

// port: build stat data from apis available on legacy windows
static inline int
win32_compat_stat_handle(HANDLE h, struct _stat64 *st)
{
	BY_HANDLE_FILE_INFORMATION info;
	ULARGE_INTEGER size;

	if (!GetFileInformationByHandle(h, &info)) {
		win32_compat_set_errno(GetLastError());
		return -1;
	}

	memset(st, 0, sizeof(*st));
	st->st_dev = info.dwVolumeSerialNumber;
	st->st_ino = info.nFileIndexLow;
	st->st_mode = (info.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ?
			_S_IFDIR | _S_IEXEC : _S_IFREG;
	st->st_mode |= _S_IREAD;
	if (!(info.dwFileAttributes & FILE_ATTRIBUTE_READONLY))
		st->st_mode |= _S_IWRITE;
	st->st_nlink = info.nNumberOfLinks;
	st->st_rdev = st->st_dev;
	size.LowPart = info.nFileSizeLow;
	size.HighPart = info.nFileSizeHigh;
	st->st_size = size.QuadPart;
	st->st_atime = win32_compat_filetime_to_time(info.ftLastAccessTime);
	st->st_mtime = win32_compat_filetime_to_time(info.ftLastWriteTime);
	st->st_ctime = win32_compat_filetime_to_time(info.ftCreationTime);
	return 0;
}

// port: replace wide stat on legacy windows
static inline int
win32_compat_wstat64(const wchar_t *path, struct _stat64 *st)
{
	HANDLE h;
	DWORD err;
	int ret;

	// port: use old file info
	h = CreateFileW(path, FILE_READ_ATTRIBUTES,
			FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
			NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);
	if (h == INVALID_HANDLE_VALUE) {
		win32_compat_set_errno(GetLastError());
		return -1;
	}
	ret = win32_compat_stat_handle(h, st);
	err = GetLastError();
	CloseHandle(h);
	SetLastError(err);
	return ret;
}

// port: replace missing reentrant time conversion on legacy windows
static inline struct tm *
win32_compat_gmtime(const time_t *timer, struct tm *result)
{
	static const int month_days[] = {
		0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334,
	};
	int64_t seconds = *timer;
	int64_t days = seconds / 86400;
	int64_t remainder = seconds % 86400;
	int64_t shifted_days;
	int64_t era;
	unsigned day_of_era;
	unsigned year_of_era;
	int64_t year;
	unsigned day_of_year;
	unsigned month_part;
	int day;
	int month;
	bool leap;

	// port: convert old time
	if (remainder < 0) {
		remainder += 86400;
		days--;
	}
	shifted_days = days + 719468;
	era = (shifted_days >= 0 ? shifted_days : shifted_days - 146096) /
		146097;
	day_of_era = shifted_days - era * 146097;
	year_of_era = (day_of_era - day_of_era / 1460 + day_of_era / 36524 -
		       day_of_era / 146096) / 365;
	year = year_of_era + era * 400;
	day_of_year = day_of_era -
		(365 * year_of_era + year_of_era / 4 - year_of_era / 100);
	month_part = (5 * day_of_year + 2) / 153;
	day = day_of_year - (153 * month_part + 2) / 5 + 1;
	month = month_part < 10 ? month_part + 3 : month_part - 9;
	year += month <= 2;
	leap = (year % 4 == 0 && year % 100 != 0) || year % 400 == 0;

	memset(result, 0, sizeof(*result));
	result->tm_sec = remainder % 60;
	result->tm_min = (remainder / 60) % 60;
	result->tm_hour = remainder / 3600;
	result->tm_mday = day;
	result->tm_mon = month - 1;
	result->tm_year = year - 1900;
	result->tm_wday = (days + 4) % 7;
	if (result->tm_wday < 0)
		result->tm_wday += 7;
	result->tm_yday = month_days[result->tm_mon] + day - 1;
	if (leap && month > 2)
		result->tm_yday++;
	result->tm_isdst = 0;
	return result;
}

#endif
