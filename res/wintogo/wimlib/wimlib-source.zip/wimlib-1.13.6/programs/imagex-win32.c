/* Windows-specific code for wimlib-imagex.  */

#ifndef __WIN32__
#  error "This file contains Windows code"
#endif

#include "imagex-win32.h"
#include <errno.h>
#include <fcntl.h>
#include <io.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <sddl.h>

#include "wimlib/win32_compat.h"

// port: use legacy windows compatibility helpers for imagex runtime calls
const wchar_t *
imagex_win32_strerror_replacement(int errnum)
{
	static wchar_t buf[256];
	const char *msg;

	// port: replace missing wide error text
	msg = strerror(errnum);
	if (!msg || mbstowcs(buf, msg, sizeof(buf) / sizeof(buf[0])) == (size_t)-1)
		buf[0] = L'\0';
	buf[(sizeof(buf) / sizeof(buf[0])) - 1] = L'\0';
	return buf;
}

// port: replace wide stat on legacy windows
int
imagex_win32_stat_replacement(const wchar_t *path, struct _stat64 *st)
{
	return win32_compat_wstat64(path, st);
}

// port: replace reentrant time conversion on legacy windows
struct tm *
imagex_win32_gmtime_replacement(const time_t *timer, struct tm *result)
{
	return win32_compat_gmtime(timer, result);
}

/* Convert a string from the "current Windows codepage" to UTF-16LE.  */
wchar_t *
win32_mbs_to_wcs(const char *mbs, size_t mbs_nbytes, size_t *num_wchars_ret)
{
	if (mbs_nbytes > INT_MAX) {
		fwprintf(stderr, L"ERROR: too much data (%zu bytes)!\n",
			 mbs_nbytes);
		return NULL;
	}
	if (mbs_nbytes == 0) {
		*num_wchars_ret = 0;
		return (wchar_t*)mbs;
	}
	int len = MultiByteToWideChar(CP_ACP,
				      MB_ERR_INVALID_CHARS,
				      mbs,
				      mbs_nbytes,
				      NULL,
				      0);
	if (len <= 0)
		goto out_invalid;
	wchar_t *wcs = malloc(len * sizeof(wchar_t));
	if (!wcs) {
		fwprintf(stderr, L"ERROR: out of memory!\n");
		return NULL;
	}
	int len2 = MultiByteToWideChar(CP_ACP,
				       MB_ERR_INVALID_CHARS,
				       mbs,
				       mbs_nbytes,
				       wcs,
				       len);
	if (len2 != len) {
		free(wcs);
		goto out_invalid;
	}
	*num_wchars_ret = len;
	return wcs;
out_invalid:
	fwprintf(stderr,
L"ERROR: Invalid multi-byte string in the text file you provided as input!\n"
L"       Maybe try converting your text file to UTF-16LE?\n"
	);
	return NULL;
}

/* Set a file descriptor to binary mode.  */
void set_fd_to_binary_mode(int fd)
{
	_setmode(fd, _O_BINARY);
}

static wchar_t *
get_security_descriptor_string(PSECURITY_DESCRIPTOR desc)
{
	typedef BOOL (WINAPI *convert_security_descriptor_t)
		(PSECURITY_DESCRIPTOR, DWORD, SECURITY_INFORMATION,
		 LPWSTR *, PULONG);
	convert_security_descriptor_t convert;
	wchar_t *str = NULL;

	// port: load this when present
	convert = (convert_security_descriptor_t)GetProcAddress(
			GetModuleHandle(L"advapi32.dll"),
			"ConvertSecurityDescriptorToStringSecurityDescriptorW");
	if (!convert) {
		SetLastError(ERROR_CALL_NOT_IMPLEMENTED);
		return NULL;
	}
	/* 52 characters!!!  */
	convert(
			desc,
			SDDL_REVISION_1,
			OWNER_SECURITY_INFORMATION |
				GROUP_SECURITY_INFORMATION |
				DACL_SECURITY_INFORMATION |
				SACL_SECURITY_INFORMATION,
			&str,
			NULL);
	return str;
}

void
win32_print_security_descriptor(const uint8_t *sd, size_t size)
{
	wchar_t *str;
	const wchar_t *printstr;
	DWORD err;

	/* 'size' is ignored here due to the crappy Windows APIs.  Oh well, this
	 * is just for debugging anyway.  */
	str = get_security_descriptor_string((PSECURITY_DESCRIPTOR)sd);
	if (str)
		printstr = str;
	else if ((err = GetLastError()) == ERROR_CALL_NOT_IMPLEMENTED)
		printstr = L"(not supported)";
	else
		printstr = L"(invalid)";

	wprintf(L"Security Descriptor = %ls\n", printstr);

	LocalFree(str);
}
