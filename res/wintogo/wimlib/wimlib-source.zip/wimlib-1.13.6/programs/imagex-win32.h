#ifndef _IMAGEX_WIN32_H
#define _IMAGEX_WIN32_H

#include <stddef.h>
#include <stdbool.h>
#include <inttypes.h>
#include <sys/stat.h>
#include <time.h>
#include <wchar.h>

extern wchar_t *
win32_mbs_to_wcs(const char *mbs, size_t mbs_nbytes, size_t *num_wchars_ret);

extern void
win32_print_security_descriptor(const uint8_t *sd, size_t size);

extern void
set_fd_to_binary_mode(int fd);

// port: provide imagex replacements for missing legacy runtime calls
extern const wchar_t *
imagex_win32_strerror_replacement(int errnum);

extern int
imagex_win32_stat_replacement(const wchar_t *path, struct _stat64 *st);

extern struct tm *
imagex_win32_gmtime_replacement(const time_t *timer, struct tm *result);

// port: route imagex runtime calls through legacy windows replacements
#undef tstrerror
#define tstrerror imagex_win32_strerror_replacement

#undef tstat
#define tstat imagex_win32_stat_replacement

#undef gmtime_r
#define gmtime_r imagex_win32_gmtime_replacement

#include "wgetopt.h"

#define optarg			woptarg
#define optind			woptind
#define opterr			wopterr
#define optopt			woptopt
#define option			woption

#define getopt_long_only	wgetopt_long_only
#define getopt_long		wgetopt_long
#define getopt			wgetopt

#endif
